package steps;

import utils.DriverManager;
import io.cucumber.java.en.Given;
import org.openqa.selenium.By;

public class LoginSteps {

    @Given("user open app")
    public void user_open_app() {

        if (DriverManager.driver == null) {
            DriverManager.initDriver();
        }

        DriverManager.driver.findElement(
            By.xpath("//android.view.ViewGroup[@resource-id='com.indomaret.klikindomaret:id/bak']")
        ).click();

        System.out.println("CLICK AKUN SUCCESS");

        DriverManager.driver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/amb']")).click();
        
        System.out.println("CLICK MASUK SUCCESS");

        DriverManager.driver.findElement(
            By.xpath("//android.widget.EditText[@text='Masukkan Nomor Handphone atau Email']")
        ).sendKeys("aherry642@gmail.com");

        System.out.println("SET TEXT EMAIL SUCCESS");

        DriverManager.driver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/28r']")).click();

        System.out.println("CLICK LOGIN SUCCESS");

        String actualMessage = DriverManager.driver.findElement(
            By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/89v']")
        ).getText();

        actualMessage = actualMessage.toLowerCase();

        if (!actualMessage.contains("tidak ditemukan")) {
            throw new AssertionError(
                "❌ VALIDATION FAILED\nExpected contains: Email tidak ditemukan\nActual: " + actualMessage
            );
        }

        System.out.println("✅ VALIDATION PASSED: " + actualMessage);
    }
}