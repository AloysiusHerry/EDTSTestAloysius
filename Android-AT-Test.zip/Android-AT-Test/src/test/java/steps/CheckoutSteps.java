package steps;

import utils.DriverManager;
import io.cucumber.java.en.Given;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class CheckoutSteps {

    @Given("user order product")
    public void user_order_product() {

        if (DriverManager.driver == null) {
            DriverManager.initDriver();
        }

        DriverManager.driver.findElement(
            By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/dtl']")
        ).click();

        System.out.println("CLICK SEARCH PRODUCT");

        WebDriverWait wait = new WebDriverWait(DriverManager.driver, Duration.ofSeconds(10));

        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//android.widget.EditText")
        ));

        el.sendKeys("Pisang");

        DriverManager.driver.executeScript("mobile: performEditorAction", java.util.Map.of("action", "search"));

        System.out.println("SET TEXT PRODUCT SUCCESS");

        WebElement el1 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("(//android.widget.ImageView[@resource-id='com.indomaret.klikindomaret:id/6ic'])[1]")
        ));

        el1.click();

        System.out.println("CLICK DETAIL PRODUCT");
        
        WebElement el2 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/9kj']")
        ));

        el2.click();

        System.out.println("CLICK ADD CART");

         WebElement el2 = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/9kj']")
        ));
        DriverManager.driver.findElement(By.xpath()).click();

        System.out.println("CLICK ADD ITEM");

        DriverManager.driver.findElement(By.xpath("//android.view.ViewGroup[@resource-id='com.indomaret.klikindomaret:id/b36']/android.widget.FrameLayout[@resource-id='com.indomaret.klikindomaret:id/ce7']")).click();

        System.out.println("CLICK CART");

        DriverManager.driver.findElement(By.xpath("//android.view.ViewGroup[@resource-id='com.indomaret.klikindomaret:id/52k']")).click();

        DriverManager.driver.findElement(By.xpath("//android.view.ViewGroup[@resource-id='com.indomaret.klikindomaret:id/53n']/android.widget.FrameLayout[@resource-id='com.indomaret.klikindomaret:id/ff8']")).click();

        DriverManager.driver.findElement(By.xpath("//android.widget.TextView[@text='Instan']")).click();
        
        DriverManager.driver.findElement(By.xpath("//android.widget.TextView[@resource-id='com.indomaret.klikindomaret:id/amb']")).click();
        
        DriverManager.driver.findElement(By.xpath("//android.widget.Button[@resource-id='com.indomaret.klikindomaret:id/c1h']")).click();
        
    }
}