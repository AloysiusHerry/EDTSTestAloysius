package utils;

public class PriceUtil {

    public static int parsePrice(String text) {
        return Integer.parseInt(text.replaceAll("[^0-9]", ""));
    }

    public static int calculateTotal(int product, int shipping, int insurance) {
        return product + shipping + insurance;
    }
}