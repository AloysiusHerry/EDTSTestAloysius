package utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;

public class DriverManager {

    public static AppiumDriver driver;

    public static void initDriver() {

        try {

            if (driver == null) {

                DesiredCapabilities caps = new DesiredCapabilities();

                // ================= BASIC CAPABILITIES =================
                caps.setCapability("platformName", "Android");
                caps.setCapability("appium:automationName", "UiAutomator2");
                caps.setCapability("appium:deviceName", "Android Device");

                // ================= DEVICE =================
                caps.setCapability("appium:udid", "10DECQ0BY9000B0");

                // ================= APP SETTINGS =================
                caps.setCapability("appium:noReset", true);
                caps.setCapability("appium:appPackage", "com.indomaret.klikindomaret");

                // OPTIONAL (kalau app kamu butuh activity spesifik)
                // caps.setCapability("appium:appActivity", "com.indomaret.klikindomaret.MainActivity");

                // ================= STABILITY SETTINGS =================
                caps.setCapability("appium:newCommandTimeout", 120);
                caps.setCapability("appium:adbExecTimeout", 60000);
                caps.setCapability("appium:ignoreHiddenApiPolicyError", true);

                // ================= INIT DRIVER =================
                driver = new AndroidDriver(
                        new URL("http://127.0.0.1:4723"),
                        caps
                );

                System.out.println("🚀 Appium Driver Started Successfully");
            }

        } catch (Exception e) {
            throw new RuntimeException("❌ Failed to initialize Appium driver", e);
        }
    }

    public static void quitDriver() {

        if (driver != null) {
            driver.quit();
            driver = null;

            System.out.println("🛑 Appium Driver Stopped");
        }
    }

    public static AppiumDriver getDriver() {
        return driver;
    }
}