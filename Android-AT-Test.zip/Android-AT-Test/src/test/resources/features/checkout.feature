Feature: Klik element test

Scenario: Tambahkan Keranjang
  Given user order product

Scenario: Test klik element dulu
  Given user open app